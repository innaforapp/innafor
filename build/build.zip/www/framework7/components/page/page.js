export default {
  name: 'page',
};
