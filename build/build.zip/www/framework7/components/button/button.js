export default {
  name: 'button',
};
