export default {
  name: 'grid',
};
