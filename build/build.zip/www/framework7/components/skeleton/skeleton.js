export default {
  name: 'skeleton',
};
