export default {
  name: 'contactsList',
};
