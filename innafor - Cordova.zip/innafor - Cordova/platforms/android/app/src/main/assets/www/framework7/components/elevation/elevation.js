export default {
  name: 'elevation',
};
