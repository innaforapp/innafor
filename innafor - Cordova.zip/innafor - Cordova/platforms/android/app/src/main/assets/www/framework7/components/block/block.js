export default {
  name: 'block',
};
