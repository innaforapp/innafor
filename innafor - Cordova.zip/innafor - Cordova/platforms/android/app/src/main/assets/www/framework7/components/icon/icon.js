export default {
  name: 'icon',
};
