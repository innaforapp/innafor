export default {
  name: 'radio',
};
