import Framework7Class from '../../../../utils/class';

export default Framework7Class;
