export default {
  name: 'page',
};
