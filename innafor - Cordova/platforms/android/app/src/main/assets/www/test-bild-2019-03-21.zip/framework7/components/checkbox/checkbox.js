export default {
  name: 'checkbox',
};
